export interface Chunk {
  name: string;
  size: number;
  sha256: string;
}

export interface Manifest {
  key: string;
  generation: number;
  size: number;
  sha256: string;
  contentType: string;
  updatedAt: string;
  chunks: Chunk[];
  replicas: string[];
}

export type NodeState = 'healthy' | 'draining' | string;

export interface NodeInfo {
  id: string;
  domain: string;
  state: NodeState;
  usedBytes: number;
  objects: number;
}

export interface Policy {
  replicas: number;
  writeAcks: number;
}

export type ClusterState = 'HEALTHY' | 'DEGRADED' | 'OFFLINE' | string;

export interface ClusterSummary {
  state: ClusterState;
  nodesHealthy: number;
  nodesTotal: number;
  objects: number;
  usedBytes: number;
  uptimeSeconds: number;
}

export interface Overview {
  cluster: ClusterSummary;
  nodes: NodeInfo[];
  policy: Policy;
  repairBacklog: number;
  repairCompleted: number;
  repairError: string;
  requests: number;
}

export type ToastKind = 'success' | 'error' | 'info';

export interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
}

export interface RecentObject {
  key: string;
  generation: string;
  size: number;
  sha256: string;
  contentType: string;
  lastAction: 'stored' | 'looked up' | 'deleted';
  at: number;
}
