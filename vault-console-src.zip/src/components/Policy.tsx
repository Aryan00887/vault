import { useEffect, useState } from 'react';
import { ApiError, putPolicy } from '../api';
import type { Overview, Policy as PolicyType } from '../types';

const PRESETS: { label: string; value: PolicyType; hint: string }[] = [
  { label: 'Max durability', value: { replicas: 3, writeAcks: 3 }, hint: '3 copies · wait for all 3' },
  { label: 'Balanced (default)', value: { replicas: 3, writeAcks: 2 }, hint: '3 copies · wait for 2' },
  { label: 'Fast writes', value: { replicas: 3, writeAcks: 1 }, hint: '3 copies · wait for 1' },
  { label: 'Minimal', value: { replicas: 1, writeAcks: 1 }, hint: '1 copy · wait for 1' },
];

export default function Policy({
  overview,
  token,
  onChanged,
  pushToast,
  onUnauthorized,
}: {
  overview: Overview | null;
  token: string;
  onChanged: () => void;
  pushToast: (kind: 'success' | 'error', message: string) => void;
  onUnauthorized: () => void;
}) {
  const nodeCount = overview?.nodes.length ?? 3;
  const [replicas, setReplicas] = useState(overview?.policy.replicas ?? 3);
  const [writeAcks, setWriteAcks] = useState(overview?.policy.writeAcks ?? 2);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (overview) {
      setReplicas(overview.policy.replicas);
      setWriteAcks(overview.policy.writeAcks);
    }
  }, [overview?.policy.replicas, overview?.policy.writeAcks]);

  const valid = replicas >= 1 && replicas <= nodeCount && writeAcks >= 1 && writeAcks <= replicas;
  const dirty = overview ? replicas !== overview.policy.replicas || writeAcks !== overview.policy.writeAcks : false;

  async function save() {
    if (!valid) return;
    setSaving(true);
    try {
      await putPolicy(token, { replicas, writeAcks });
      pushToast('success', `Policy updated: ${replicas} copies, ${writeAcks} to acknowledge.`);
      onChanged();
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        onUnauthorized();
        return;
      }
      pushToast('error', err instanceof Error ? err.message : 'Could not update the policy.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="stack">
      <section className="panel">
        <div className="panel__header">
          <h2 className="panel__title">Replication policy</h2>
        </div>
        <p className="panel__lead">
          Vault keeps <strong>{replicas}</strong> durable {replicas === 1 ? 'copy' : 'copies'} of
          every object and waits for <strong>{writeAcks}</strong> of{' '}
          {writeAcks === 1 ? 'it' : 'them'} to be written to disk before acknowledging a write.
        </p>

        <div className="policy-form">
          <div className="field">
            <label className="field-label" htmlFor="replicas">
              Replicas
            </label>
            <input
              id="replicas"
              type="number"
              min={1}
              max={nodeCount}
              value={replicas}
              onChange={(e) => setReplicas(Number(e.target.value))}
              className="text-input text-input--mono text-input--narrow"
            />
            <span className="field-hint">1 – {nodeCount} nodes available</span>
          </div>
          <div className="field">
            <label className="field-label" htmlFor="writeAcks">
              Write acknowledgements
            </label>
            <input
              id="writeAcks"
              type="number"
              min={1}
              max={Math.max(replicas, 1)}
              value={writeAcks}
              onChange={(e) => setWriteAcks(Number(e.target.value))}
              className="text-input text-input--mono text-input--narrow"
            />
            <span className="field-hint">must be ≤ replicas</span>
          </div>
        </div>

        {!valid && (
          <p className="field-error">
            Replicas and write acknowledgements must satisfy 1 ≤ writeAcks ≤ replicas ≤ {nodeCount}.
          </p>
        )}

        <div className="policy-presets">
          {PRESETS.filter((p) => p.value.replicas <= nodeCount).map((p) => (
            <button
              key={p.label}
              className="chip"
              onClick={() => {
                setReplicas(p.value.replicas);
                setWriteAcks(p.value.writeAcks);
              }}
            >
              <span className="chip__label">{p.label}</span>
              <span className="chip__hint">{p.hint}</span>
            </button>
          ))}
        </div>

        <button
          className="btn btn--primary"
          disabled={!valid || !dirty || saving}
          onClick={save}
        >
          {saving ? 'Saving…' : 'Save policy'}
        </button>
      </section>
    </div>
  );
}
