import { useState } from 'react';
import type { FormEvent } from 'react';
import { ApiError, getOverview } from '../api';
import type { Overview } from '../types';

export default function Login({
  onConnect,
}: {
  onConnect: (token: string, overview: Overview) => void;
}) {
  const [token, setToken] = useState('');
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = token.trim();
    if (!trimmed) {
      setError('Enter the operator token to continue.');
      return;
    }
    setConnecting(true);
    setError(null);
    try {
      const overview = await getOverview(trimmed);
      onConnect(trimmed, overview);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setError('That token was rejected. Check VAULT_ADMIN_TOKEN on the server.');
      } else {
        setError(err instanceof Error ? err.message : 'Could not reach the Vault API.');
      }
    } finally {
      setConnecting(false);
    }
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-mark">
          <span className="login-mark__glyph">V</span>
        </div>
        <h1 className="login-title">Vault</h1>
        <p className="login-subtitle">Connect to the storage cluster with an operator token.</p>
        <form onSubmit={handleSubmit} className="login-form">
          <label className="field-label" htmlFor="token">
            Operator token
          </label>
          <input
            id="token"
            type="password"
            autoFocus
            autoComplete="off"
            spellCheck={false}
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder="dev-vault-token"
            className="text-input text-input--mono"
          />
          {error && <p className="field-error">{error}</p>}
          <button type="submit" className="btn btn--primary btn--block" disabled={connecting}>
            {connecting ? 'Connecting…' : 'Connect'}
          </button>
        </form>
        <p className="login-hint">
          Set by <code>VAULT_ADMIN_TOKEN</code> on the server. In local development this defaults
          to <code>dev-vault-token</code>.
        </p>
      </div>
    </div>
  );
}
