import { useState } from 'react';
import { ApiError, nodeAction } from '../api';
import type { Overview } from '../types';
import { NodeStatusPill } from './StatusPill';
import { formatBytes } from '../utils/format';

export default function Nodes({
  overview,
  token,
  onChanged,
  pushToast,
  onUnauthorized,
}: {
  overview: Overview | null;
  token: string;
  onChanged: () => void;
  pushToast: (kind: 'success' | 'error', message: string) => void;
  onUnauthorized: () => void;
}) {
  const [pending, setPending] = useState<Record<string, boolean>>({});

  if (!overview) return <div className="panel panel--loading">Loading nodes…</div>;

  const { nodes, policy } = overview;
  const healthyCount = nodes.filter((n) => n.state === 'healthy').length;

  async function act(id: string, action: 'drain' | 'restore') {
    setPending((p) => ({ ...p, [id]: true }));
    try {
      await nodeAction(token, id, action);
      pushToast('success', `${id} is now ${action === 'drain' ? 'draining' : 'healthy'}.`);
      onChanged();
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        onUnauthorized();
        return;
      }
      pushToast('error', err instanceof Error ? err.message : `Could not ${action} ${id}.`);
    } finally {
      setPending((p) => ({ ...p, [id]: false }));
    }
  }

  return (
    <div className="stack">
      {healthyCount < policy.writeAcks && (
        <div className="banner banner--danger">
          Write quorum is not satisfiable: {healthyCount} of {policy.writeAcks} required nodes are
          healthy. Writes will fail until a node is restored.
        </div>
      )}
      {healthyCount >= policy.writeAcks && healthyCount < policy.replicas && (
        <div className="banner banner--warn">
          Running degraded: only {healthyCount} of {policy.replicas} desired replicas can currently
          be placed.
        </div>
      )}

      <section className="panel">
        <div className="panel__header">
          <h2 className="panel__title">Storage nodes</h2>
          <span className="panel__meta">
            {healthyCount} / {nodes.length} healthy
          </span>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Node</th>
              <th>Rack</th>
              <th>State</th>
              <th>Objects</th>
              <th>Used</th>
              <th aria-label="Actions" />
            </tr>
          </thead>
          <tbody>
            {nodes.map((n) => {
              const isHealthy = n.state === 'healthy';
              const busy = !!pending[n.id];
              return (
                <tr key={n.id}>
                  <td className="mono">{n.id}</td>
                  <td>{n.domain}</td>
                  <td>
                    <NodeStatusPill state={n.state} />
                  </td>
                  <td className="num">{n.objects.toLocaleString()}</td>
                  <td className="num mono">{formatBytes(n.usedBytes)}</td>
                  <td className="table__actions">
                    {isHealthy ? (
                      <button
                        className="btn btn--warn btn--small"
                        disabled={busy}
                        onClick={() => act(n.id, 'drain')}
                      >
                        {busy ? 'Draining…' : 'Drain node'}
                      </button>
                    ) : (
                      <button
                        className="btn btn--ok btn--small"
                        disabled={busy}
                        onClick={() => act(n.id, 'restore')}
                      >
                        {busy ? 'Restoring…' : 'Restore node'}
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="panel__footnote">
          Draining a node marks it unhealthy for new placements and reads; the repair loop moves
          its replicas elsewhere. This affects the local prototype process only.
        </p>
      </section>
    </div>
  );
}
