import type { Overview as OverviewData } from '../types';
import { NodeStatusPill } from './StatusPill';
import { formatBytes, formatUptime } from '../utils/format';

export default function Overview({
  overview,
  error,
  onRetry,
}: {
  overview: OverviewData | null;
  error: string | null;
  onRetry: () => void;
}) {
  if (error && !overview) {
    return (
      <div className="panel panel--error">
        <p className="panel-error-title">Couldn't load the cluster summary</p>
        <p className="panel-error-message">{error}</p>
        <button className="btn btn--secondary" onClick={onRetry}>
          Retry
        </button>
      </div>
    );
  }

  if (!overview) {
    return <div className="panel panel--loading">Loading cluster state…</div>;
  }

  const { cluster, nodes, policy, repairBacklog, repairCompleted, repairError, requests } = overview;

  return (
    <div className="stack">
      <section className="stat-grid">
        <Stat label="Objects stored" value={cluster.objects.toLocaleString()} />
        <Stat label="Used across nodes" value={formatBytes(cluster.usedBytes)} />
        <Stat label="Nodes healthy" value={`${cluster.nodesHealthy} / ${cluster.nodesTotal}`} />
        <Stat label="Uptime" value={formatUptime(cluster.uptimeSeconds)} />
        <Stat label="Requests served" value={requests.toLocaleString()} />
        <Stat label="Replication policy" value={`${policy.replicas} copies · ${policy.writeAcks} to ack`} />
      </section>

      {repairError && (
        <div className="banner banner--danger">
          Last repair attempt failed: <span className="mono">{repairError}</span>
        </div>
      )}
      {!repairError && repairBacklog > 0 && (
        <div className="banner banner--warn">
          {repairBacklog} object{repairBacklog === 1 ? '' : 's'} below the target replica count.
          The repair loop runs automatically every 15 seconds.
        </div>
      )}

      <section className="panel">
        <div className="panel__header">
          <h2 className="panel__title">Nodes</h2>
          <span className="panel__meta">{repairCompleted.toLocaleString()} repairs completed</span>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Node</th>
              <th>Rack</th>
              <th>State</th>
              <th>Objects</th>
              <th>Used</th>
            </tr>
          </thead>
          <tbody>
            {nodes.map((n) => (
              <tr key={n.id}>
                <td className="mono">{n.id}</td>
                <td>{n.domain}</td>
                <td>
                  <NodeStatusPill state={n.state} />
                </td>
                <td className="num">{n.objects.toLocaleString()}</td>
                <td className="num mono">{formatBytes(n.usedBytes)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="stat">
      <div className="stat__value">{value}</div>
      <div className="stat__label">{label}</div>
    </div>
  );
}
