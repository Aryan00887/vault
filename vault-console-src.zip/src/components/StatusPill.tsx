type Tone = 'ok' | 'warn' | 'danger' | 'neutral';

const CLUSTER_TONE: Record<string, Tone> = {
  HEALTHY: 'ok',
  DEGRADED: 'warn',
  OFFLINE: 'danger',
};

const NODE_TONE: Record<string, Tone> = {
  healthy: 'ok',
  draining: 'warn',
};

const NODE_LABEL: Record<string, string> = {
  healthy: 'Healthy',
  draining: 'Draining',
};

export function ClusterStatusPill({ state, pulse }: { state: string; pulse?: boolean }) {
  const tone = CLUSTER_TONE[state] ?? 'neutral';
  return (
    <span className={`status-pill status-pill--${tone}`}>
      <span className={`status-dot status-dot--${tone}${pulse && tone !== 'ok' ? ' status-dot--pulse' : ''}`} />
      {state.charAt(0) + state.slice(1).toLowerCase()}
    </span>
  );
}

export function NodeStatusPill({ state }: { state: string }) {
  const tone = NODE_TONE[state] ?? 'neutral';
  const label = NODE_LABEL[state] ?? state;
  return (
    <span className={`status-pill status-pill--${tone}`}>
      <span className={`status-dot status-dot--${tone}`} />
      {label}
    </span>
  );
}
