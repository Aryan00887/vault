import { Boxes, Gauge, Server, Settings2 } from 'lucide-react';

export type Tab = 'overview' | 'objects' | 'nodes' | 'policy';

const NAV: { id: Tab; label: string; icon: typeof Gauge }[] = [
  { id: 'overview', label: 'Overview', icon: Gauge },
  { id: 'objects', label: 'Objects', icon: Boxes },
  { id: 'nodes', label: 'Nodes', icon: Server },
  { id: 'policy', label: 'Policy', icon: Settings2 },
];

export default function Sidebar({ tab, onSelect }: { tab: Tab; onSelect: (t: Tab) => void }) {
  return (
    <nav className="sidebar">
      <div className="sidebar__brand">
        <span className="sidebar__brand-mark">V</span>
        <div>
          <div className="sidebar__brand-name">Vault</div>
          <div className="sidebar__brand-sub">Object storage</div>
        </div>
      </div>
      <ul className="sidebar__nav">
        {NAV.map(({ id, label, icon: Icon }) => (
          <li key={id}>
            <button
              className={`sidebar__item${tab === id ? ' sidebar__item--active' : ''}`}
              onClick={() => onSelect(id)}
              aria-current={tab === id ? 'page' : undefined}
            >
              <Icon size={17} strokeWidth={1.75} />
              <span>{label}</span>
            </button>
          </li>
        ))}
      </ul>
      <div className="sidebar__footer">Single-process prototype</div>
    </nav>
  );
}
